<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);
/*
  Listar todo el contenido de una película o serie
 */
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    if (isset($_GET['idPs']))
    {
      //Mostrar contenido de una película o serie
      $sql = $dbConn->prepare("SELECT * FROM contenido WHERE idPsFK=:idPs");
      $sql->bindValue(':idPs', $_GET['idPs']);
      $sql->execute();
      $sql->setFetchMode(PDO::FETCH_ASSOC);
      header("HTTP/1.1 200 OK");
      echo json_encode($sql->fetchAll());
      exit();
    }
    else 
    {
        //Mostrar lista de contenido
        $sql = $dbConn->prepare("SELECT * FROM contenido");
        $sql->execute();
        $sql->setFetchMode(PDO::FETCH_ASSOC);
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetchAll());
        exit();
    }
}
// Crear un nuevo contenido
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $input = $_POST;
    $sql = "INSERT INTO contenido VALUES (null,'".$_POST['fechaInicioContenido']."', '".$_POST['fechaFinalContenido']."', '".$_POST['opinionContenido']."', 
    '".$_POST['personajeContenido']."', '".$_POST['valoracionContenido']."', ".$_POST['idPsFK'].")";
    $statement = $dbConn->prepare($sql);
    $statement->execute();
    $postId = $dbConn->lastInsertId();
    if($postId)
    {
      $input['idContenido'] = $postId;
      header("HTTP/1.1 200 OK");
      echo json_encode($input);
      exit();
   }
}
// Borrar
if ($_SERVER['REQUEST_METHOD'] == 'DELETE')
{
  $idContenido = $_GET['idContenido'];
  $statement = $dbConn->prepare("DELETE FROM contenido WHERE idContenido=:idContenido");
  $statement->bindValue(':idContenido', $idContenido);
  $statement->execute();
  header("HTTP/1.1 200 OK");
  exit();
}
// Actualizar
if ($_SERVER['REQUEST_METHOD'] == 'PUT')
{
    $input = $_GET;
	$sql = "UPDATE contenido SET fechaInicioContenido='".$input['fechaInicioContenido']."', fechaFinalContenido='".$input['fechaFinalContenido']."', 
  opinionContenido='".$input['opinionContenido']."', personajeContenido='".$input['personajeContenido']."', valoracionContenido='".$input['valoracionContenido']."', 
  WHERE idContenido=".$input['idContenido'];
    $statement = $dbConn->prepare($sql);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}
// En caso de que ninguna de las opciones anteriores se haya ejecutado
header("HTTP/1.1 400 Bad Request");
?>
