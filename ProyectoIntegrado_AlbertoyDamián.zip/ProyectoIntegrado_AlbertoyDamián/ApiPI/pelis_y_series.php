<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);
/*
  Listar todos los registros o solo uno
 */
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    if (isset($_GET['idPs']))
    {
      //Mostrar una película o serie
      $sql = $dbConn->prepare("SELECT * FROM pelis_y_series WHERE idPs=:idPs");
      $sql->bindValue(':idPs', $_GET['idPs']);
      $sql->execute();
      header("HTTP/1.1 200 OK");
      echo json_encode($sql->fetch(PDO::FETCH_ASSOC));
      exit();
    }
    else 
	  {
        //Mostrar lista de películas y series
        $sql = $dbConn->prepare("SELECT * FROM pelis_y_series");
        $sql->execute();
        $sql->setFetchMode(PDO::FETCH_ASSOC);
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetchAll());
        exit();
    }
}
// Crear una nueva película o serie
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $input = $_POST;
    $sql = "INSERT INTO pelis_y_series VALUES (null,'".$_POST['nombrePs']."', '".$_POST['tipoPs']."')";
    $statement = $dbConn->prepare($sql);
    $statement->execute();
    $postId = $dbConn->lastInsertId();
    if($postId)
    {
      $input['idPs'] = $postId;
      header("HTTP/1.1 200 OK");
      echo json_encode($input);
      exit();
   }
}
// Borrar
if ($_SERVER['REQUEST_METHOD'] == 'DELETE')
{
  $idPs = $_GET['idPs'];
  $statement = $dbConn->prepare("DELETE FROM pelis_y_series WHERE idPs=:idPs");
  $statement->bindValue(':idPs', $idPs);
  $statement->execute();
  header("HTTP/1.1 200 OK");
  exit();
}
// Actualizar
if ($_SERVER['REQUEST_METHOD'] == 'PUT')
{
    $input = $_GET;
	$sql = "UPDATE pelis_y_series SET nombrePs='".$input['nombrePs']."', tipoPs='".$input['tipoPs']."' WHERE idPs=".$input['idPs'];
    $statement = $dbConn->prepare($sql);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}
// En caso de que ninguna de las opciones anteriores se haya ejecutado
header("HTTP/1.1 400 Bad Request");
?>
