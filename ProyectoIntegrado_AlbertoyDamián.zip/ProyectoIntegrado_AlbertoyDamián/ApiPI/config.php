<?php
$db = [
    'host' => 'localhost',
    'username' => 'rest',
    'password' => 'Studium2020;',
    'db' => 'proyecto_integrado'
];
?>
