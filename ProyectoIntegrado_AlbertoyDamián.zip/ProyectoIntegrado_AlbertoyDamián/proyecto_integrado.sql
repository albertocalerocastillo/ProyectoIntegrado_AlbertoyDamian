CREATE DATABASE  IF NOT EXISTS `proyecto_integrado` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `proyecto_integrado`;
-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: proyecto_integrado
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contenido`
--

DROP TABLE IF EXISTS `contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contenido` (
  `idContenido` int NOT NULL AUTO_INCREMENT,
  `fechaInicioContenido` varchar(50) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `fechaFinalContenido` varchar(50) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `opinionContenido` varchar(500) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `personajeContenido` varchar(50) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `valoracionContenido` decimal(3,1) DEFAULT NULL,
  `idPsFK` int DEFAULT NULL,
  PRIMARY KEY (`idContenido`),
  KEY `contenido_ibfk_1` (`idPsFK`),
  CONSTRAINT `contenido_ibfk_1` FOREIGN KEY (`idPsFK`) REFERENCES `pelis_y_series` (`idPs`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contenido`
--

LOCK TABLES `contenido` WRITE;
/*!40000 ALTER TABLE `contenido` DISABLE KEYS */;
INSERT INTO `contenido` VALUES (1,'10 de febrero de 2022','7 de agosto de 2022','Me ha encantado, la mejor serie que he visto en mi vida. Nunca veré otra mejor.','Walter White',9.8,1);
/*!40000 ALTER TABLE `contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelis_y_series`
--

DROP TABLE IF EXISTS `pelis_y_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelis_y_series` (
  `idPs` int NOT NULL AUTO_INCREMENT,
  `nombrePs` varchar(100) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  `tipoPs` varchar(50) COLLATE utf8mb4_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`idPs`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelis_y_series`
--

LOCK TABLES `pelis_y_series` WRITE;
/*!40000 ALTER TABLE `pelis_y_series` DISABLE KEYS */;
INSERT INTO `pelis_y_series` VALUES (1,'Breaking Bad','Serie');
/*!40000 ALTER TABLE `pelis_y_series` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-13 20:33:31
