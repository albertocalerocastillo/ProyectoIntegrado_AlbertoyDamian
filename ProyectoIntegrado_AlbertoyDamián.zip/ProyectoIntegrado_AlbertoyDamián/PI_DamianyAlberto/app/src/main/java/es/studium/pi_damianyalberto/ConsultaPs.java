package es.studium.pi_damianyalberto;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ConsultaPs extends AsyncTask<Void, Void, String> {
    JSONArray result;
    JSONObject jsonobject;
    List<PelisySeries> items = new ArrayList();

    public ConsultaPs() {
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(Void... argumentos) {
        try {
            URL url = new URL("http://192.168.88.1/ApiPI/pelis_y_series.php");
            HttpURLConnection myConnection = (HttpURLConnection) url.openConnection();
            myConnection.setRequestMethod("GET");
            if (myConnection.getResponseCode() == 200) {
                InputStream responseBody = myConnection.getInputStream();
                InputStreamReader responseBodyReader =
                        new InputStreamReader(responseBody, "UTF-8");
                BufferedReader bR = new BufferedReader(responseBodyReader);
                String line = "";
                StringBuilder responseStrBuilder = new StringBuilder();
                while ((line = bR.readLine()) != null) {
                    responseStrBuilder.append(line);
                }
                result = new JSONArray(responseStrBuilder.toString());
                for (int i = 0; i < result.length(); i++) {
                    try {
                        jsonobject = result.getJSONObject(i);
                        items.add(new PelisySeries(jsonobject.getInt("idPs"), jsonobject.getString("nombrePs"), jsonobject.getString("tipoPs")));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                responseBody.close();
                responseBodyReader.close();
                myConnection.disconnect();
            } else {
                Log.println(Log.ERROR, "Error", "¡Conexión fallida!");
            }
        } catch (Exception e) {
            Log.println(Log.ERROR, "Error", "¡Conexión fallida!");
        }
        return (null);
    }

    protected void onPostExecute(String mensaje) {
    }
}