package es.studium.pi_damianyalberto;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class ModificacionContenido extends AsyncTask<Void, Void, String> {
    int idContenido, idPsFK;
    String fechaInicioContenido, fechaFinalContenido, opinionContenido, personajeContenido;
    double valoracionContenido;

    public ModificacionContenido(int id, String fechaInicio, String fechaFinal, String opinion, String personaje, double valoracion, int idFK) {
        this.idContenido = id;
        this.fechaInicioContenido = fechaInicio;
        this.fechaFinalContenido = fechaFinal;
        this.opinionContenido = opinion;
        this.personajeContenido = personaje;
        this.valoracionContenido = valoracion;
        this.idPsFK = idFK;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(Void... voids) {
        try {
            String response = "";
            Uri uri = new Uri.Builder()
                    .scheme("http")
                    .authority("192.168.88.1")
                    .path("/ApiPI/contenido.php")
                    .appendQueryParameter("idContenido", String.valueOf(idContenido))
                    .appendQueryParameter("fechaInicioContenido", fechaInicioContenido)
                    .appendQueryParameter("fechaFinalContenido", fechaFinalContenido)
                    .appendQueryParameter("opinionContenido", opinionContenido)
                    .appendQueryParameter("personajeContenido", personajeContenido)
                    .appendQueryParameter("valoracionContenido", String.valueOf(valoracionContenido))
                    .appendQueryParameter("idPsFK", String.valueOf(idPsFK))
                    .build();
            URL url = new URL(uri.toString());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(15000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("PUT");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = br.readLine()) != null) {
                    response += line;
                }
            } else {
                response = "";
            }
            connection.getResponseCode();
            if (connection.getResponseCode() == 200) {
                Log.println(Log.ASSERT, "Resultado", "Registro modificado: " + response);
                connection.disconnect();
            } else {
                Log.println(Log.ASSERT, "Error", "Error");
            }
        } catch (Exception e) {
            Log.println(Log.ASSERT, "Excepción", e.getMessage());
        }
        return null;
    }

    protected void onPostExecute(String mensaje) {
    }
}