package es.studium.pi_damianyalberto;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class AltaPs extends AsyncTask<Void, Void, String> {
    String nombrePs;
    String tipoPs;

    public AltaPs(String nombrePs, String tipoPs) {
        this.nombrePs = nombrePs;
        this.tipoPs = tipoPs;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(Void... argumentos) {
        try {
            URL url = new URL("http://192.168.88.1/ApiPI/pelis_y_series.php");
            HttpURLConnection myConnection = (HttpURLConnection) url.openConnection();
            myConnection.setRequestMethod("POST");
            HashMap<String, String> postDataParams = new HashMap<String, String>();
            postDataParams.put("nombrePs", nombrePs);
            postDataParams.put("tipoPs", tipoPs);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            OutputStream os = myConnection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));
            writer.flush();
            writer.close();
            os.close();
            myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                myConnection.disconnect();
            } else {
                Log.println(Log.ASSERT, "Error", "Error");
            }
        } catch (Exception e) {
            Log.println(Log.ASSERT, "Excepción", e.getMessage());
        }
        return null;
    }

    private String getPostDataString(HashMap<String, String> params)
            throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
}
