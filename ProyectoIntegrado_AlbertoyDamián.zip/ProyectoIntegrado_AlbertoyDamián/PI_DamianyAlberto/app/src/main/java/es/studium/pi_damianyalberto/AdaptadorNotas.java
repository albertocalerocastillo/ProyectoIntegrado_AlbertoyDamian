package es.studium.pi_damianyalberto;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorNotas extends RecyclerView.Adapter<AdaptadorNotas.NotasViewHolder> {
    private List<Contenido> items;

    public static class NotasViewHolder extends RecyclerView.ViewHolder {
        public TextView fechaInicio, fechaFinal, opinion, personaje, valoracion;

        public NotasViewHolder(View v) {
            super(v);
            fechaInicio = v.findViewById(R.id.txtFechaInicio);
            fechaFinal = v.findViewById(R.id.txtFechaFinal);
            opinion = v.findViewById(R.id.txtOpinion);
            personaje = v.findViewById(R.id.txtPersonaje);
            valoracion = v.findViewById(R.id.txtValoracion);
        }
    }

    public AdaptadorNotas(List<Contenido> items) {
        this.items = items;
    }

    @Override

    public int getItemCount() {
        return items.size();
    }

    @Override

    public NotasViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fila2, viewGroup, false);
        return new NotasViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NotasViewHolder notasViewHolder, @SuppressLint("RecyclerView") int i) {
        notasViewHolder.fechaInicio.setText(items.get(i).getFechaInicioContenido());
        notasViewHolder.fechaFinal.setText(items.get(i).getFechaFinalContenido());
        notasViewHolder.opinion.setText(items.get(i).getOpinionContenido());
        notasViewHolder.personaje.setText(items.get(i).getPersonajeContenido());
        notasViewHolder.valoracion.setText(String.valueOf(items.get(i).getValoracionContenido()));
    }
}