package es.studium.pi_damianyalberto;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Notas extends AppCompatActivity {
    private RecyclerView recycler;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager lManager;
    FloatingActionButton botonNuevo;
    DialogoAltaContenido altaContenido;
    ConsultaContenido consulta;

    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);

        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            id = extra.getInt("id");
            consulta = new ConsultaContenido(String.valueOf(id));
            consulta.execute();
            rellenarCardView();
        } else {
            // Manejar el caso en que el Bundle sea nulo
            // Por ejemplo, mostrar un mensaje de error o cerrar la actividad
            finish(); // Cierra la actividad actual si el Bundle es nulo
        }

        botonNuevo = findViewById(R.id.botonAñadir);
        botonNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                altaContenido = new DialogoAltaContenido(id);
                altaContenido.setCancelable(false);
                altaContenido.show(getSupportFragmentManager(), "Nombre");
            }
        });
    }



    public void rellenarCardView() {
        recycler = (RecyclerView) findViewById(R.id.recyclerNotas);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(Notas.this);
        recycler.setLayoutManager(layoutManager);
        adapter = new AdaptadorNotas(consulta.items);
        recycler.setAdapter(adapter);
    }
}