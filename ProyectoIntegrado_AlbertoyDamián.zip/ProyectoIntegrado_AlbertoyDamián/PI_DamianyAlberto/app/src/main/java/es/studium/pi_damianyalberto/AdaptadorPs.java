package es.studium.pi_damianyalberto;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorPs extends RecyclerView.Adapter<AdaptadorPs.CuadernosViewHolder> {
    public List<PelisySeries> items;
    MainActivity activity = new MainActivity();

    public static class CuadernosViewHolder extends RecyclerView.ViewHolder {
        public TextView titulo;
        public TextView tipo;

        public CuadernosViewHolder(View v) {
            super(v);
            titulo = (TextView) v.findViewById(R.id.txtTitulo);
            tipo = (TextView) v.findViewById(R.id.txtTipo);
        }
    }

    public AdaptadorPs(List<PelisySeries> items) {
        this.items = items;
    }

    @Override

    public int getItemCount() {
        return items.size();
    }

    @Override

    public CuadernosViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fila1, viewGroup, false);
        return new CuadernosViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CuadernosViewHolder cuadernosViewHolder, @SuppressLint("RecyclerView") int i) {
        cuadernosViewHolder.titulo.setText(items.get(i).getNombrePs());
        cuadernosViewHolder.tipo.setText(items.get(i).getTipoPs());
        cuadernosViewHolder.titulo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                DialogoBajaPs bajaPs = new DialogoBajaPs(items.get(i).getId());
                bajaPs.setCancelable(false);
                bajaPs.show(((MainActivity) view.getContext()).getSupportFragmentManager(), "Nombre");
                return true;
            }
        });

        cuadernosViewHolder.titulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Notas.class);
                intent.putExtra("id", items.get(i).getId());
                view.getContext().startActivity(intent);
            }
        });
    }
}