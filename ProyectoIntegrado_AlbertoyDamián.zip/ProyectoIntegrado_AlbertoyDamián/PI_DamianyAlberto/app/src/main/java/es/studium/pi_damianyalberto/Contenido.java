package es.studium.pi_damianyalberto;

public class Contenido {
    public int id;
    int idPsFK;
    public String fechaInicioContenido;
    public String fechaFinalContenido;
    public String opinionContenido;
    public String personajeContenido;
    public double valoracionContenido;

    public Contenido(int id, String fechaInicioContenido, String fechaFinalContenido, String opinionContenido, String personajeContenido, double valoracionContenido, int idPsFK) {
        this.id = id;
        this.fechaInicioContenido = fechaInicioContenido;
        this.fechaFinalContenido = fechaFinalContenido;
        this.opinionContenido = opinionContenido;
        this.personajeContenido = personajeContenido;
        this.valoracionContenido = valoracionContenido;
        this.idPsFK = idPsFK;
    }

    public Contenido(String fechaInicioContenido, String fechaFinalContenido, String opinionContenido, String personajeContenido, double valoracionContenido) {
        this.fechaInicioContenido = fechaInicioContenido;
        this.fechaFinalContenido = fechaFinalContenido;
        this.opinionContenido = opinionContenido;
        this.personajeContenido = personajeContenido;
        this.valoracionContenido = valoracionContenido;
    }


    public int getId() {
        return id;
    }

    public int getidPsFK() {
        return idPsFK;
    }

    public String getFechaInicioContenido() {
        return fechaInicioContenido;
    }

    public String getFechaFinalContenido() {
        return fechaFinalContenido;
    }

    public String getOpinionContenido() {
        return opinionContenido;
    }

    public String getPersonajeContenido() {
        return personajeContenido;
    }

    public double getValoracionContenido() {
        return valoracionContenido;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIdPsFK(int idPsFK) {
        this.idPsFK = idPsFK;
    }

    public void setFechaInicioContenido(String fechaInicioContenido) {
        this.fechaInicioContenido = fechaInicioContenido;
    }

    public void setFechaFinalContenido(String fechaFinalContenido) {
        this.fechaFinalContenido = fechaFinalContenido;
    }

    public void setOpinionContenido(String opinionContenido) {
        this.opinionContenido = opinionContenido;
    }

    public void setPersonajeContenido(String personajeContenido) {
        this.personajeContenido = personajeContenido;
    }

    public void setValoracionContenido(double valoracionContenido) {
        this.valoracionContenido = valoracionContenido;
    }
}
