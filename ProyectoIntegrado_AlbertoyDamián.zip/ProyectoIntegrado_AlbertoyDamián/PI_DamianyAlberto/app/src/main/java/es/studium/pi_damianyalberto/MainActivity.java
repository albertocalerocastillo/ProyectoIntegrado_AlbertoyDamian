package es.studium.pi_damianyalberto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton botonNuevo;
    DialogoAltaPs altaCuadernos;

    private RecyclerView recycler;
    private RecyclerView.Adapter adapter;
    ConsultaPs consulta = new ConsultaPs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        consulta.execute();
        rellenarCardView();
        botonNuevo = findViewById(R.id.botonAñadir);
        botonNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                altaCuadernos = new DialogoAltaPs();
                altaCuadernos.setCancelable(false);
                altaCuadernos.show(getSupportFragmentManager(), "Nombre");
            }
        });
    }

    public void rellenarCardView() {
        recycler = (RecyclerView) findViewById(R.id.recyclerCuadernos);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
        recycler.setLayoutManager(layoutManager);
        adapter = new AdaptadorPs(consulta.items);
        recycler.setAdapter(adapter);

    }
}