package es.studium.pi_damianyalberto;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class AltaContenido extends AsyncTask<Void, Void, String> {
    String fechaInicioContenido, fechaFinalContenido, opinionContenido, personajeContenido;
    double valoracionContenido;
    int idPsFK;

    public AltaContenido(String fechaInicioContenido, String fechaFinalContenido, String opinionContenido, String personajeContenido, double valoracionContenido, int idPsFK) {
        this.fechaInicioContenido = fechaInicioContenido;
        this.fechaFinalContenido = fechaFinalContenido;
        this.opinionContenido = opinionContenido;
        this.personajeContenido = personajeContenido;
        this.valoracionContenido = valoracionContenido;
        this.idPsFK = idPsFK;
    }

    public AltaContenido(int idPsFK) {
        this.idPsFK = idPsFK;
    }

    protected void onPreExecute() {
    }

    protected String doInBackground(Void... argumentos) {
        try {
            URL url = new URL("http://192.168.88.1/ApiPI/contenido.php");
            HttpURLConnection myConnection = (HttpURLConnection) url.openConnection();
            myConnection.setRequestMethod("POST");
            HashMap<String, String> postDataParams = new HashMap<String, String>();
            postDataParams.put("fechaInicioContenido", fechaInicioContenido);
            postDataParams.put("fechaFinalContenido", fechaFinalContenido);
            postDataParams.put("opinionContenido", opinionContenido);
            postDataParams.put("personajeContenido", personajeContenido);
            postDataParams.put("valoracionContenido", String.valueOf(valoracionContenido));
            postDataParams.put("idPsFK", "" + idPsFK);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            OutputStream os = myConnection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));
            writer.flush();
            writer.close();
            os.close();
            myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                myConnection.disconnect();
            } else {
                Log.println(Log.ASSERT, "Error", "Error");
            }
        } catch (Exception e) {
            Log.println(Log.ASSERT, "Excepción", e.getMessage());
        }
        return (null);
    }

    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
}
