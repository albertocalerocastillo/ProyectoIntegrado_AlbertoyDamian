package es.studium.pi_damianyalberto;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class DialogoAltaPs extends DialogFragment {

    private EditText nombreEditText;
    private EditText tipoEditText;

    public DialogoAltaPs() {
    }

    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.fragment_dialogo_alta_cuadernos, null);
        nombreEditText = v.findViewById(R.id.editNombre);
        tipoEditText = v.findViewById(R.id.editTipo);

        builder.setView(v);
        builder.setTitle(R.string.tituloPs)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (nombreEditText.length() != 0 && tipoEditText.length() != 0) {
                            AltaPs altaC = new AltaPs(nombreEditText.getText().toString(), tipoEditText.getText().toString());
                            altaC.execute();
                            dialog.dismiss();
                        } else {
                            Toast.makeText(v.getContext(), "Faltan datos por completar", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        return builder.create();
    }
}
