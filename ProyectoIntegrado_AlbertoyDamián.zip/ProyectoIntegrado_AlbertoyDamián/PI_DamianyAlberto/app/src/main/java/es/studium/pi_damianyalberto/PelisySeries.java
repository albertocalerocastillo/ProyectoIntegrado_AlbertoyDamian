package es.studium.pi_damianyalberto;

public class PelisySeries {
    public int id;
    public String nombrePs;
    public String tipoPs;

    public PelisySeries(int id, String nombrePs, String tipoPs) {
        this.id = id;
        this.nombrePs = nombrePs;
        this.tipoPs = tipoPs;
    }

    public PelisySeries(String nombrePs, String tipoPs) {
        this.nombrePs = nombrePs;
        this.tipoPs = tipoPs;
    }

    public int getId() {
        return id;
    }

    public String getNombrePs() {
        return nombrePs;
    }

    public String getTipoPs() {
        return tipoPs;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombrePs(String nombrePs) {
        this.nombrePs = nombrePs;
    }

    public void setTipoPs(String tipoPs) {
        this.tipoPs = tipoPs;
    }
}
