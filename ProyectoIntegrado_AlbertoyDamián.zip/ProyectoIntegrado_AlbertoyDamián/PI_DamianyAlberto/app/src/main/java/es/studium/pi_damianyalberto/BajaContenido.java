package es.studium.pi_damianyalberto;

import android.os.AsyncTask;
import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;

public class BajaContenido {

    private class BajaRemota extends AsyncTask<Void, Void, String> {
        String idContenido;

        public BajaRemota(String id) {
            this.idContenido = id;
        }

        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URI baseUri = new URI("http://192.168.88.1/ApiPI/contenido.php");
                String[] parametros = {"idContenido", this.idContenido};
                URI uri = applyParameters(baseUri, parametros);
                HttpURLConnection myConnection = (HttpURLConnection)
                        uri.toURL().openConnection();
                myConnection.setRequestMethod("DELETE");
                if (myConnection.getResponseCode() == 200) {
                    Log.println(Log.ASSERT, "Resultado", "Registro borrado");
                    myConnection.disconnect();
                } else {
                    Log.println(Log.ASSERT, "Error", "Error");
                }
            } catch (Exception e) {
                Log.println(Log.ASSERT, "Excepción", e.getMessage());
            }
            return null;
        }

        protected void onPostExecute(String mensaje) {
        }

        URI applyParameters(URI uri, String[] urlParameters) {
            StringBuilder query = new StringBuilder();
            boolean first = true;
            for (int i = 0; i < urlParameters.length; i += 2) {
                if (first) {
                    first = false;
                } else {
                    query.append("&");
                }
                try {
                    query.append(urlParameters[i]).append("=")
                            .append(URLEncoder.encode(urlParameters[i + 1], "UTF-8"));
                } catch (UnsupportedEncodingException ex) {
                    throw new RuntimeException(ex);
                }
            }
            try {
                return new URI(uri.getScheme(), uri.getAuthority(),
                        uri.getPath(), query.toString(), null);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}