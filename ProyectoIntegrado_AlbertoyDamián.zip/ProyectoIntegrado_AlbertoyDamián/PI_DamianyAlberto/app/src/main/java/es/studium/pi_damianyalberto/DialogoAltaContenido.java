package es.studium.pi_damianyalberto;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class DialogoAltaContenido extends DialogFragment {

    EditText fechaInicio, fechaFinal, opinion, personaje, valoracion;
    int id;

    public DialogoAltaContenido(int id) {
        this.id = id;
    }

    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.fragment_dialogo_alta_apuntes, null);
        fechaInicio = v.findViewById(R.id.editFechaInicio);
        fechaFinal = v.findViewById(R.id.editFechaFinal);
        opinion = v.findViewById(R.id.editOpinion);
        personaje = v.findViewById(R.id.editPersonaje);
        valoracion = v.findViewById(R.id.editValoracion);
        builder.setView(v);
        builder.setTitle(R.string.tituloContenido)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (fechaInicio.length() != 0) {
                            dialog.dismiss();
                            AltaContenido altaC = new AltaContenido(fechaInicio.getText().toString(), fechaFinal.getText().toString(), opinion.getText().toString(), personaje.getText().toString(), Double.parseDouble(valoracion.getText().toString()), id);
                            altaC.execute();
                            Intent refresh = new Intent(getContext(), Notas.class);
                            startActivity(refresh);
                        } else {
                            Toast.makeText(v.getContext(), "Faltan datos por completar", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        return builder.create();
    }
}