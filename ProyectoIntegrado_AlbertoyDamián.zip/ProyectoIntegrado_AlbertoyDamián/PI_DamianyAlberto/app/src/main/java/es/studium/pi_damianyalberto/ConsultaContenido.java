package es.studium.pi_damianyalberto;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class ConsultaContenido extends AsyncTask<Void, Void, String> {
    JSONArray result;
    JSONObject jsonobject;
    String idFK;
    List<Contenido> items = new ArrayList();

    public ConsultaContenido(String idPs) {
        idFK = idPs;
    }

    protected void onPreExecute() {
    }

    @Override
    protected String doInBackground(Void... voids) {
        try {
            URI baseUri = new URI("http://192.168.88.1/ApiPI/contenido.php");
            Log.println(Log.DEBUG, "", "" + idFK);
            String[] parametros = {"idPs", idFK};
            URI uri = applyParameters(baseUri, parametros);
            HttpURLConnection myConnection = (HttpURLConnection)
                    uri.toURL().openConnection();
            myConnection.setRequestMethod("GET");
            if (myConnection.getResponseCode() == 200) {
                InputStream responseBody = myConnection.getInputStream();
                InputStreamReader responseBodyReader =
                        new InputStreamReader(responseBody, "UTF-8");
                BufferedReader bR = new BufferedReader(responseBodyReader);
                String line = "";
                StringBuilder responseStrBuilder = new StringBuilder();
                while ((line = bR.readLine()) != null) {
                    responseStrBuilder.append(line);
                }
                result = new JSONArray(responseStrBuilder.toString());
                for (int i = 0; i < result.length(); i++) {
                    try {
                        jsonobject = result.getJSONObject(i);
                        items.add(new Contenido(jsonobject.getInt("idContenido"), jsonobject.getString("fechaInicioContenido"), jsonobject.getString("fechaFinalContenido"), jsonobject.getString("opinionContenido"), jsonobject.getString("personajeContenido"), jsonobject.getDouble("valoracionContenido"), jsonobject.getInt("idPsFK")));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                responseBody.close();
                responseBodyReader.close();
                myConnection.disconnect();
            } else {
                Log.println(Log.ASSERT, "Error", "Error");
            }
        } catch (Exception e) {
            Log.println(Log.ASSERT, "Excepción", e.getMessage());
        }
        return null;
    }

    protected void onPostExecute(String mensaje) {
    }

    URI applyParameters(URI uri, String[] urlParameters) {
        StringBuilder query = new StringBuilder();
        boolean first = true;
        for (int i = 0; i < urlParameters.length; i += 2) {
            if (first) {
                first = false;
            } else {
                query.append("&");
            }
            try {
                query.append(urlParameters[i]).append("=")
                        .append(URLEncoder.encode(urlParameters[i + 1], "UTF-8"));
            } catch (UnsupportedEncodingException ex) {
                throw new RuntimeException(ex);
            }
        }
        try {
            return new URI(uri.getScheme(), uri.getAuthority(),
                    uri.getPath(), query.toString(), null);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}